#include<bits/stdc++.h>
using namespace std;
int main()
{
	/*
	BST (Balanced) advantages :

	search , insert , delete , find closest - O(logn)
	sorted traversal - O(n)

	Note: if tree not balanced then O(h) where h=height of tree
	*/
	return 0;
}