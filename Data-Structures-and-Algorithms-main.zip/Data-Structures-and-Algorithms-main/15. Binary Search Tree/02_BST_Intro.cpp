#include<bits/stdc++.h>
using namespace std;
int main()
{
	/*
	BST Properties :

	1.left of root node contains node smaller than root node
	2.right of root contains node greater than root node
	3.all nodes are distinct
	4.STL : map,multimap,set,multiset
	5.Not cache friendly
	*/
	return 0;
}