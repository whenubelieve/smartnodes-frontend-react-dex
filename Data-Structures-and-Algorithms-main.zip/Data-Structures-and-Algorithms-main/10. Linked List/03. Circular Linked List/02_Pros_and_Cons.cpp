#include<bits/stdc++.h>
using namespace std;

int main()
{
	/*
	Advantages :
	
	a.can traverse whole list from any node
	b.can insert at head/tail by keeping tail pointer in O(1)
	c.round robin easy implementation

	Disadvantages :

	a.implementaion become complex
	*/

	return 0;
}