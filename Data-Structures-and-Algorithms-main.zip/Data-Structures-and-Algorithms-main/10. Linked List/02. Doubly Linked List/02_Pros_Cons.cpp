#include<bits/stdc++.h>
using namespace std;

int main()
{
	/*
	Advantages :

	a.traversal in both directions
	b.insert/delete in O(1) if given pointer to it

	Disadvantages :

	a.extra space for prev
	b.code becomes complex
	*/

	return 0;
}