#include<bits/stdc++.h>
using namespace std;

int main()
{
	string s;
	getline(cin,s);//getline function reads full string "parth garg"

	cout<<s;
	return 0;
}