#include<bits/stdc++.h>
using namespace std;

int main()
{
	/*

	Stable Algorithms :

	1.Bubble Sort
	2.Insertion Sort
	3.Merge Sort

	Unstable Algorithms :

	1.Selection
	2.Quick Sort
	3.Heap Sort

	*/

	return 0;
}
