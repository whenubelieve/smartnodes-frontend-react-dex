#include<bits/stdc++.h>
using namespace std;

int main()
{
	/*

	Features :

	1.divide and conquer algorithm

	2.worst case time : O(n^2)

	3.faster because of :

		a.in-place
		b.cache friendly
		c.average case is O(n*logn)
		d.tail recursive

	4.partition is key funtion(naive,lomuto,hoare)

	*/
}