#include<bits/stdc++.h>
using namespace std;

int main()
{
	/*

	What is partitoning ?

	arr[]={3,8,6,12,10,7};
	p=5;

	p is the index of element which is taken as pivot element

	so, 7 is the pivot element

	output : 2

	explaination:

	arr[]={3,6,7,8,12,10}

	after setting 7 to its correct position we return index of 7 in new array

	*/
}