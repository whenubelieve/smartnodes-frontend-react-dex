#include<bits/stdc++.h>
using namespace std;

int main()
{
	/*

	Stable Algorithms :

		Naive

	Unstable Algorithms :

		a.Lomuto
		b.Hoare (more efficient)

	*/
}