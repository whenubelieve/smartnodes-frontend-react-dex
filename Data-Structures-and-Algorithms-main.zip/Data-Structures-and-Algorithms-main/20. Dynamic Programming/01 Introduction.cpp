#include<bits/stdc++.h>
using namespace std;
int main()
{
	/*
	Dynamic Programming :

	1.optimization over recursion
	2.reuse the solutions of overlapping sub-problem

	Types:

	1.Memoization (top down)
	2.Tabulation (down top)
	*/

	return 0;
}